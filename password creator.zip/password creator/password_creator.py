#passwword project


from cryptography.fernet import Fernet  
import os


#==========================This is the Welcome message==================================

print('Welcome to the Password Portal!\n\n')          
#This is where I encrypt your passwords
date = input('what is todays date? (use mm/dd/yy): ')
key = Fernet.generate_key()


#this is grabbing the master password originally set by the write_key function
def load_key():
    file = open('key.key', 'rb')
    key = file.read()
    file.close()
    return key

master_password = input("What is your Master password?: ")
key = load_key() + master_password.encode()
fer = Fernet(key)

#This is where I encrypt your passwords


def view():                                 # This is the view  mode, it shows the existing accounts logged in passwords.txt
    print('\n\n\n')
    print('#####################################')
    with open('passwords.txt', "r") as f:
        for line in f.readlines():
            data = line.rstrip()
            user, password, service = data.split('|')
            print('\n#  User:', user, "|" " Password:",
                  fer.decrypt(password.encode()).decode())
            print('Service: ', service)

    with open('passwords.txt') as my_file:
            my_file.seek(0, os.SEEK_END)
            if my_file.tell():
                my_file.seek(0)
            else:
                print('File is empty...')
    print('######################################')

def add():                                  # This mode allows you to add an account to passwords.txt
    service = input('What Service is the Account for?: ')
    name = input('Account Name: ')
    password = input("Password: ")
    with open('passwords.txt', "a") as f:
        f.write(name + "|" + (fer.encrypt(password.encode())).decode() + '|' + service + '\n')

def remove():                                #This is the remove mode, it will allow you to delete all data in passwords.txt then will print the data in passwords.txt (there should be no data)
    f = open('passwords.txt', 'r+')
    f.truncate(0)


#==================================Main Menu============================================

while True:
    mode = input('\n\n\nWould you like to add a new password, view existing passwords, or remove all profiles and start fresh?\n (Add, View, Remove), or press q to quit: ').lower()
    if mode == 'q':             # This will exit / quit the program
        break
    if mode == "view":          # This is the view  mode, it shows the existing accounts logged in passwords.txt
        view()
        print('\n\n\n')
    elif mode == "add":         # This mode allows you to add an account to passwords.txt
        add()
        print('\n\n\n')
    elif mode == "remove":
        remove()
        print('You have successfully Removed all accounts from passwords.txt')
        def is_non_zero_file(fpath):  
            return os.path.isfile(fpath) and os.path.getsize(fpath) > 0
        view()
        print('\n\n\n')
    else:
        print('Invalid Mode.\n\n\n')  # Invalid mode statement
        continue

#==================================Main Menu============================================